(Espacio para los badges de MATLAB Online y File Exchange)

# (Adicione aquí el Titulo de la Actividad de Enseñanza)

## Autor
Adicione su nombre y afiliaci

## Resumen de la actividad
Por favor, proporcione una breve descripción de su actividad o tarea y sus resultados. 
Asegúrese de incluir palabras clave para ayudar otros a encontrar sus materiales utilizando nuestras funciones de búsqueda/navegación.

## Contexto o pre-requisitos
Este texto debería ayudar a otros docentes a comprender las situaciones de enseñanza para las cuales esta actividad es apropiada.

## Asignaturas o departmento donde se puede usar la Actividad

## Notas para los Educadores usando la Actividad
Esta sección debe incluir notas y consejos para los instructores que podrían utilizar la actividad.

## Evaluación
Describe brevemente cómo determinas si los estudiantes han alcanzado los objetivos de esta tarea o actividad.
O si la actividad es exploratoria

## Recursos adicionales
Esta sección debe incluir referencias y enlaces a recursos en línea que discutan la actividad específica o que apoyen a los docentes
y/o estudiantes que utilicen la actividad.